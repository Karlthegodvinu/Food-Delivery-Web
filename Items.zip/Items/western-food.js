document.addEventListener("DOMContentLoaded", function () {
    const burgers = document.querySelectorAll(".burger");

    burgers.forEach(burger => {
        const countSpan = burger.querySelector(".count");
        const increaseBtn = burger.querySelector(".increase");
        const decreaseBtn = burger.querySelector(".decrease");

        increaseBtn.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent parent div click
            let count = parseInt(burger.getAttribute("data-count")) + 1;
            burger.setAttribute("data-count", count);
            countSpan.textContent = count;
        });

        decreaseBtn.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent parent div click
            let count = parseInt(burger.getAttribute("data-count"));
            if (count > 0) {
                count -= 1;
                burger.setAttribute("data-count", count);
                countSpan.textContent = count;
            }
        });
    });
});
